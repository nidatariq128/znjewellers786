import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Watch, ShoppingBag } from 'lucide-react';
import { ProductCategory } from '../../types';

interface HeroProps {
  onShopCollection: () => void;
  onExploreMore: () => void;
  onSelectCategory: (category: ProductCategory) => void;
  onQuickViewHeroProduct: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onShopCollection,
  onExploreMore,
}) => {
  return (
    <section className="relative w-full min-h-[80vh] lg:min-h-[85vh] flex items-center overflow-hidden bg-[#080808] border-b border-[#221c13]">
      
      {/* Ambient Luxury Atmospheric Lighting */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#D6B16D]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-[32rem] h-[32rem] bg-[#A67C2E]/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl w-full mx-auto px-6 lg:px-12 py-12 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center z-10">
        
        {/* Left Column: Editorial & Brand Copy (Columns 1-7) */}
        <div className="lg:col-span-7 space-y-7">
          
          {/* Tagline Badge */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#141009] border border-[#3b301c]">
            <Sparkles className="w-3.5 h-3.5 text-[#D6B16D] animate-pulse" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#D6B16D] font-medium">
              Elegance That Lasts Forever.
            </span>
          </div>

          {/* Main Heading */}
          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-serif text-white font-normal tracking-tight leading-[1.14]">
              Bespoke Nikkah Essentials,{' '}
              <span className="gold-gradient-text italic font-serif">Watches</span>, Bangles & Handbags.
            </h1>
          </div>

          {/* Luxury Brand Description */}
          <p className="text-sm sm:text-base text-neutral-300 font-light leading-relaxed max-w-xl">
            Explore our signature collection of customized Nikkah mirror platters and signature pens, traditional bridal velvet & kundan bangles, prestigious luxury timepieces, designer handbags, and waterproof stainless steel jewellery.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-1">
            <button
              onClick={onShopCollection}
              className="px-7 py-3.5 bg-gradient-to-r from-[#D6B16D] via-[#F4E0A5] to-[#C29B53] text-black text-xs uppercase tracking-[0.2em] font-semibold rounded hover:shadow-[0_0_30px_rgba(214,177,109,0.4)] hover:scale-[1.01] transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer shadow-lg shadow-black/80"
            >
              <span>Explore All Collections</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreMore}
              className="px-7 py-3.5 bg-[#120f0a] border border-[#3d321d] text-neutral-200 text-xs uppercase tracking-[0.2em] font-medium rounded hover:border-[#D6B16D] hover:text-[#D6B16D] hover:bg-[#18140c] transition-all duration-300 flex items-center justify-center cursor-pointer"
            >
              Our Story
            </button>
          </div>

          {/* Trust Highlights - Aligned with ZN JEWELLERS Actual Categories */}
          <div className="pt-6 border-t border-[#1f1911] grid grid-cols-3 gap-4 max-w-lg">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <Sparkles className="w-4 h-4 text-[#D6B16D]" />
                <span>Nikkah Essentials</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Platters, Pens & Boxes</p>
            </div>
            
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <Watch className="w-4 h-4 text-[#D6B16D]" />
                <span>Watches & Bangles</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Bridal Kadas & Watches</p>
            </div>
            
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <ShoppingBag className="w-4 h-4 text-[#D6B16D]" />
                <span>Bags & Steel Jewellery</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Handbags & Anti-Tarnish</p>
            </div>
          </div>

        </div>

        {/* Right Column: Categories Showcase Visual (Columns 8-12) */}
        <div className="lg:col-span-5 relative flex items-center justify-center">
          
          {/* Subtle Ambient Gold Aura Behind Image */}
          <div className="absolute w-80 h-80 bg-[#D6B16D]/15 rounded-full blur-[90px] pointer-events-none" />

          {/* Tastefully Scaled Visual Container featuring Nikkah essentials, bangles, watch, handbag & jewellery */}
          <div className="relative w-full max-w-md lg:max-w-lg aspect-[16/10] flex items-center justify-center select-none">
            <img
              src="/zn-categories-showcase.jpg"
              alt="ZN JEWELLERS Customised Nikkah Essentials, Bangles, Watches, Handbags & Steel Jewellery"
              className="w-full h-full object-contain object-center filter brightness-95 contrast-[1.05] drop-shadow-[0_20px_45px_rgba(0,0,0,0.95)]"
            />

            {/* Seamless Soft Feathering at Edges so it melts naturally into the #080808 background */}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#080808] via-transparent to-[#080808]/40 opacity-70" />
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-[#080808] via-transparent to-[#080808] opacity-50" />
          </div>

        </div>

      </div>

    </section>
  );
};
