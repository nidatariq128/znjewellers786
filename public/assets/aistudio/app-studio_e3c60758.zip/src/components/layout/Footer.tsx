import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Truck, 
  Clock, 
  Award, 
  Send, 
  CheckCircle,
  Phone,
  Mail,
  MapPin,
  Instagram,
  Facebook
} from 'lucide-react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { ProductCategory } from '../../types';

interface FooterProps {
  onNavigateCategory: (category: ProductCategory | 'all') => void;
  onNavigateTracking: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigateCategory,
  onNavigateTracking,
  onOpenAdmin
}) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubmitting(true);
    try {
      await addDoc(collection(db, 'subscribers'), {
        email: email.trim().toLowerCase(),
        subscribedAt: new Date().toISOString()
      });
      setSubscribed(true);
      setEmail('');
    } catch (err) {
      console.warn('Subscribed locally:', err);
      setSubscribed(true);
      setEmail('');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <footer className="bg-[#050505] text-neutral-300 border-t border-[#1e1911]">
      
      {/* 1. Trust & Authenticity Banner */}
      <div className="border-b border-[#1c1710] py-12 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="flex items-start gap-4 p-4 rounded-lg bg-[#0a0a0a] border border-[#231d13]">
            <Sparkles className="w-8 h-8 text-[#D6B16D] shrink-0 mt-1" />
            <div>
              <h4 className="text-sm font-serif font-semibold text-white tracking-wider">Customised Nikkah Sets</h4>
              <p className="text-xs text-neutral-400 mt-1">Bespoke mirror pen boxes, feather signing pens & ceremony platters with name engraving.</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-lg bg-[#0a0a0a] border border-[#231d13]">
            <Truck className="w-8 h-8 text-[#D6B16D] shrink-0 mt-1" />
            <div>
              <h4 className="text-sm font-serif font-semibold text-white tracking-wider">Free Delivery on ₨ 5,000</h4>
              <p className="text-xs text-neutral-400 mt-1">Fast courier shipping across Karachi, Lahore, Islamabad & all Pakistan cities.</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-lg bg-[#0a0a0a] border border-[#231d13]">
            <Clock className="w-8 h-8 text-[#D6B16D] shrink-0 mt-1" />
            <div>
              <h4 className="text-sm font-serif font-semibold text-white tracking-wider">Watches & Bridal Bangles</h4>
              <p className="text-xs text-neutral-400 mt-1">Curated men's & women's timepieces, velvet choodiyan sets and antique kadas.</p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-lg bg-[#0a0a0a] border border-[#231d13]">
            <ShieldCheck className="w-8 h-8 text-[#D6B16D] shrink-0 mt-1" />
            <div>
              <h4 className="text-sm font-serif font-semibold text-white tracking-wider">Anti-Tarnish 18K PVD Steel</h4>
              <p className="text-xs text-neutral-400 mt-1">100% waterproof everyday jewellery and premium designer leather handbags.</p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Footer Links & Newsletter */}
      <div className="py-16 px-6 lg:px-12 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
        
        {/* Col 1 & 2: Brand Story & Newsletter */}
        <div className="lg:col-span-2 space-y-6">
          <div className="space-y-3">
            <img 
              src="/logo.png" 
              alt="ZN JEWELLERS - Elegance That Lasts Forever" 
              className="h-16 w-auto object-contain filter drop-shadow-[0_2px_15px_rgba(214,177,109,0.2)]" 
            />
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed max-w-md">
            For decades, ZN JEWELLERS has redefined modern royal luxury. We marry timeless Pakistani heritage with contemporary high-jewellery aesthetics, forging heirloom treasures of supreme beauty.
          </p>

          {/* Newsletter Box */}
          <div className="pt-2">
            <h5 className="text-xs uppercase tracking-[0.2em] text-[#D6B16D] mb-3 font-medium">
              Join The Private Salon
            </h5>
            <p className="text-xs text-neutral-400 mb-3">
              Receive confidential invitations to preview private collections and bridal salon showcases.
            </p>
            {subscribed ? (
              <div className="flex items-center gap-2 text-xs text-[#D6B16D] bg-[#1a160f] p-3 rounded border border-[#3b311e]">
                <CheckCircle className="w-4 h-4 text-[#D6B16D]" />
                <span>Thank you. You have been enrolled in our private salon registry.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  required
                  className="bg-[#12100c] border border-[#3b311e] text-neutral-200 text-xs px-4 py-2.5 rounded focus:outline-none focus:border-[#D6B16D] w-full placeholder:text-neutral-500"
                />
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2.5 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded hover:bg-[#F4E0A5] transition-colors shrink-0 flex items-center gap-1.5"
                >
                  <span>{submitting ? 'Enrolling...' : 'Join'}</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Col 3: Collections */}
        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#D6B16D] font-medium">Collections</h4>
          <ul className="space-y-2.5 text-xs text-neutral-400">
            <li>
              <button onClick={() => onNavigateCategory('Customised Nikkah Essentials')} className="hover:text-[#D6B16D] transition-colors text-left">
                Customised Nikkah Essentials
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateCategory('Watches')} className="hover:text-[#D6B16D] transition-colors text-left">
                Men's & Women's Watches
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateCategory('Handbags')} className="hover:text-[#D6B16D] transition-colors text-left">
                Designer Handbags & Clutches
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateCategory('Bangles')} className="hover:text-[#D6B16D] transition-colors text-left">
                Bridal Bangles & Kadas
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateCategory('Stainless Steel Jewellery')} className="hover:text-[#D6B16D] transition-colors text-left">
                Stainless Steel Jewellery
              </button>
            </li>
            <li>
              <button onClick={() => onNavigateCategory('all')} className="hover:text-[#D6B16D] transition-colors text-left text-[#D6B16D]">
                View All Collections →
              </button>
            </li>
          </ul>
        </div>

        {/* Col 4: Client Services & Orders */}
        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#D6B16D] font-medium">Client Services</h4>
          <ul className="space-y-2.5 text-xs text-neutral-400">
            <li>
              <button onClick={onNavigateTracking} className="hover:text-[#D6B16D] transition-colors text-left">
                Track Luxury Order
              </button>
            </li>
            <li>
              <span className="text-neutral-400">Complimentary Ring Sizing</span>
            </li>
            <li>
              <span className="text-neutral-400">Custom Bridal Consultation</span>
            </li>
            <li>
              <span className="text-neutral-400">Hallmarking Certification</span>
            </li>
            <li>
              <span className="text-neutral-400">Care & Lifetime Maintenance</span>
            </li>
            <li>
              <button onClick={onOpenAdmin} className="text-[#D6B16D]/80 hover:text-[#D6B16D] transition-colors text-left flex items-center gap-1 mt-2">
                <Sparkles className="w-3 h-3" />
                <span>Admin Management Portal</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Col 5: Ateliers & Contact */}
        <div className="space-y-4">
          <h4 className="text-xs uppercase tracking-[0.2em] text-[#D6B16D] font-medium">Flagship Ateliers</h4>
          <div className="space-y-3 text-xs text-neutral-400">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-[#D6B16D] shrink-0 mt-0.5" />
              <span>Block 4, Clifton, Karachi & Gulberg III, Lahore, Pakistan</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-[#D6B16D] shrink-0" />
              <span>+92 300 8294711 / +92 21 35874400</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-[#D6B16D] shrink-0" />
              <span>concierge@znjewellers.com</span>
            </div>
          </div>

          <div className="pt-2 flex items-center gap-4 text-neutral-400">
            <a href="#instagram" className="hover:text-[#D6B16D] transition-colors p-2 bg-[#12100c] border border-[#2a2315] rounded-full">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#facebook" className="hover:text-[#D6B16D] transition-colors p-2 bg-[#12100c] border border-[#2a2315] rounded-full">
              <Facebook className="w-4 h-4" />
            </a>
          </div>
        </div>

      </div>

      {/* 3. Bottom Legal Bar */}
      <div className="border-t border-[#1a150e] py-6 px-6 lg:px-12 text-center text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} ZN JEWELLERS. All Rights Reserved. Crafted with Timeless Excellence.</p>
          <div className="flex items-center gap-6 text-[11px] tracking-wider uppercase">
            <span className="hover:text-neutral-400 cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-neutral-400 cursor-pointer">Terms & Conditions</span>
            <span>•</span>
            <span className="hover:text-neutral-400 cursor-pointer">Security & Hallmarking</span>
          </div>
        </div>
      </div>

    </footer>
  );
};
