import React, { useState } from 'react';
import { MessageSquare, Phone, Sparkles, X, Send } from 'lucide-react';

export const ConciergeButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setMessage('');
      setIsOpen(false);
    }, 2500);
  };

  return (
    <>
      {/* Floating Pill Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="px-4 py-3 bg-[#110e09] border border-[#D6B16D]/60 text-[#D6B16D] rounded-full shadow-2xl hover:bg-[#D6B16D] hover:text-black transition-all duration-300 flex items-center gap-2.5 group cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#D6B16D] group-hover:text-black animate-pulse" />
          <span className="text-xs uppercase tracking-wider font-semibold">VIP Concierge</span>
        </button>
      </div>

      {/* Floating Concierge Drawer / Card */}
      {isOpen && (
        <div className="fixed bottom-20 right-6 z-50 w-80 sm:w-96 rounded-2xl bg-[#0c0a07] border border-[#3d311c] shadow-2xl p-5 text-white animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-[#241c12]">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-serif font-semibold text-white">ZN Bridal Salon Concierge</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-neutral-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="py-3 text-xs text-neutral-300 space-y-2">
            <p>
              Direct consultation with our Senior Gemologist in Karachi & Lahore. We assist with bespoke ring design, custom bridal sets, and private showroom visits.
            </p>
            <div className="p-2.5 rounded-lg bg-[#141009] border border-[#261f13] space-y-1 text-[11px] text-neutral-400">
              <p>📞 <strong>Direct Line:</strong> +92 300 8294711</p>
              <p>📍 <strong>Clifton Atelier:</strong> Open 11:00 AM – 9:00 PM PKT</p>
            </div>
          </div>

          {sent ? (
            <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-700 text-xs text-emerald-300 text-center">
              ✓ Message dispatched to our senior concierge desk. We will connect with you momentarily.
            </div>
          ) : (
            <form onSubmit={handleSend} className="space-y-2">
              <textarea
                rows={2}
                placeholder="Ask regarding ring sizing, custom gold casting, or delivery..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="w-full bg-[#141009] border border-[#2b2114] rounded-lg p-2.5 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#D6B16D]"
              />
              <button
                type="submit"
                className="w-full py-2 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded hover:bg-[#F4E0A5] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Dispatch Inquiry</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      )}
    </>
  );
};
