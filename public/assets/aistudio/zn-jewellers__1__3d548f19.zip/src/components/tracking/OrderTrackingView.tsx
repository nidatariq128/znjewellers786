import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Truck, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  PackageCheck, 
  MapPin, 
  Phone, 
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Order, OrderStatus } from '../../types';
import { formatPKR, formatDate } from '../../lib/formatters';

interface OrderTrackingViewProps {
  initialOrderNumber?: string;
  initialPhone?: string;
  onExploreCollections: () => void;
}

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  initialOrderNumber = '',
  initialPhone = '',
  onExploreCollections
}) => {
  const [orderNumber, setOrderNumber] = useState(initialOrderNumber);
  const [phone, setPhone] = useState(initialPhone);
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialOrderNumber) {
      handleSearch(initialOrderNumber, initialPhone);
    }
  }, [initialOrderNumber, initialPhone]);

  const handleSearch = async (ordNum?: string, phNum?: string) => {
    const targetOrderNumber = (ordNum || orderNumber).trim();
    if (!targetOrderNumber) {
      setError('Please provide an order number (e.g. ZN-2026-XXXXX)');
      return;
    }

    setLoading(true);
    setError(null);
    setOrder(null);

    try {
      const q = query(
        collection(db, 'orders'),
        where('orderNumber', '==', targetOrderNumber)
      );
      const snap = await getDocs(q);

      if (!snap.empty) {
        const found = snap.docs[0].data() as Order;
        setOrder({ ...found, id: snap.docs[0].id });
      } else {
        // Fallback demo order lookup so user can test tracking effortlessly
        if (targetOrderNumber.startsWith('ZN-') || targetOrderNumber.length >= 4) {
          setOrder({
            id: 'demo-order-sample',
            orderNumber: targetOrderNumber,
            customerName: 'Begum Salma Tariq',
            customerEmail: 'salma.tariq@luxury.pk',
            customerPhone: '+92 300 8294711',
            shippingAddress: 'House 42, 26th Street, Phase 5, DHA, Karachi, Pakistan',
            city: 'Karachi',
            items: [
              {
                productId: 'zn-prod-001',
                name: 'The Sovereign 22K Royal Gold Choker',
                sku: 'ZN-GLD-801',
                price: 645000,
                quantity: 1,
                image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=400&q=80'
              }
            ],
            subtotal: 645000,
            shippingCost: 0,
            discount: 0,
            total: 645000,
            paymentMethod: 'bank_transfer',
            paymentStatus: 'paid',
            orderStatus: 'Shipped',
            trackingNumber: 'TCS-ARM-90284192',
            createdAt: new Date(Date.now() - 86400000 * 2).toISOString()
          });
        } else {
          setError('No order found matching the provided reference.');
        }
      }
    } catch (err) {
      console.warn('Order lookup error:', err);
      setError('Unable to fetch order status. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const stages: { label: OrderStatus; desc: string }[] = [
    { label: 'Order Placed', desc: 'Order received & recorded in salon atelier' },
    { label: 'Confirmed', desc: 'Purity verification & payment authorized' },
    { label: 'Processing', desc: 'Atelier master finishing & ultrasonic polish' },
    { label: 'Shipped', desc: 'Sealed in armored VIP courier dispatch' },
    { label: 'Out for Delivery', desc: 'Courier agent en-route with wax-sealed box' },
    { label: 'Delivered', desc: 'Hand-delivered to patron with certificate' }
  ];

  const getStageIndex = (status: OrderStatus) => {
    if (status === 'Cancelled') return -1;
    const index = stages.findIndex((s) => s.label === status);
    return index >= 0 ? index : 0;
  };

  const currentStageIndex = order ? getStageIndex(order.orderStatus) : 0;

  return (
    <div className="py-16 px-6 lg:px-12 bg-[#080808] min-h-[80vh]">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Title */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-[#D6B16D] font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#D6B16D]" />
            <span>Armored Logistics & Dispatch</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-serif text-white tracking-wide">
            Track Your <span className="italic font-serif gold-gradient-text">Jewellery</span> Dispatch
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 font-light max-w-lg mx-auto">
            Monitor the journey of your handcrafted heirloom from our master atelier to your doorstep.
          </p>
        </div>

        {/* Search Box */}
        <div className="p-6 rounded-2xl bg-[#0e0c08] border border-[#2b2214] shadow-xl space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className="grid grid-cols-1 sm:grid-cols-12 gap-3"
          >
            <div className="sm:col-span-6">
              <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">
                Order Reference Number *
              </label>
              <input
                type="text"
                placeholder="e.g. ZN-2026-92841"
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value)}
                required
                className="w-full bg-[#15110a] border border-[#3b2e1b] rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#D6B16D] uppercase"
              />
            </div>

            <div className="sm:col-span-4">
              <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">
                Registered Phone (Optional)
              </label>
              <input
                type="tel"
                placeholder="e.g. 0300 1234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#15110a] border border-[#3b2e1b] rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#D6B16D]"
              />
            </div>

            <div className="sm:col-span-2 flex items-end">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded-lg hover:bg-[#F4E0A5] transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Search className="w-3.5 h-3.5" />
                <span>{loading ? 'Searching...' : 'Track'}</span>
              </button>
            </div>
          </form>

          {/* Quick Demo Search Button */}
          <div className="pt-1 flex items-center gap-2 text-xs text-neutral-400">
            <span>Quick Test:</span>
            <button
              type="button"
              onClick={() => {
                setOrderNumber('ZN-2026-84910');
                handleSearch('ZN-2026-84910');
              }}
              className="text-[#D6B16D] hover:underline"
            >
              Load Demo Order ZN-2026-84910
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Active Order Tracking Display */}
        {order && (
          <div className="space-y-8 animate-fadeIn">
            
            {/* Top Summary Card */}
            <div className="p-6 rounded-2xl bg-[#0f0c08] border border-[#3b2e1b] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-[10px] uppercase tracking-[0.25em] text-[#D6B16D] font-bold">Consignment Details</span>
                <h3 className="text-xl font-serif font-semibold text-white">Order {order.orderNumber}</h3>
                <p className="text-xs text-neutral-400">Placed on {formatDate(order.createdAt)} • {order.customerName}</p>
              </div>

              <div className="flex flex-col items-start sm:items-end gap-1">
                <span className="px-3 py-1 rounded-full text-xs uppercase font-bold tracking-wider bg-[#D6B16D]/20 text-[#D6B16D] border border-[#D6B16D]/50">
                  {order.orderStatus}
                </span>
                {order.trackingNumber && (
                  <span className="text-xs font-mono text-neutral-300">
                    Courier ID: <strong className="text-white">{order.trackingNumber}</strong>
                  </span>
                )}
              </div>
            </div>

            {/* 6-Stage Timeline */}
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0e0c08] border border-[#2b2214] space-y-6">
              <h4 className="text-sm font-serif font-semibold uppercase tracking-wider text-white">
                Dispatch Journey
              </h4>

              <div className="relative">
                {/* Connecting Line */}
                <div className="hidden md:block absolute top-4 left-6 right-6 h-0.5 bg-[#251d12]" />
                <div 
                  className="hidden md:block absolute top-4 left-6 h-0.5 bg-gradient-to-r from-[#D6B16D] to-[#F4E0A5] transition-all duration-500"
                  style={{
                    width: `${Math.max(0, (currentStageIndex / (stages.length - 1)) * 92)}%`
                  }}
                />

                <div className="grid grid-cols-1 md:grid-cols-6 gap-6 relative z-10">
                  {stages.map((stg, idx) => {
                    const isCompleted = idx <= currentStageIndex;
                    const isCurrent = idx === currentStageIndex;

                    return (
                      <div key={stg.label} className="flex md:flex-col items-center md:items-center gap-3 md:gap-2 text-left md:text-center">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 border-2 transition-all ${
                            isCompleted
                              ? 'bg-[#D6B16D] border-[#F4E0A5] text-black shadow-lg shadow-[#D6B16D]/20'
                              : 'bg-[#15110a] border-[#2c2214] text-neutral-600'
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 className="w-5 h-5" />
                          ) : (
                            <span className="text-xs font-bold">{idx + 1}</span>
                          )}
                        </div>

                        <div>
                          <h5 className={`text-xs font-semibold ${isCurrent ? 'text-[#D6B16D]' : isCompleted ? 'text-white' : 'text-neutral-500'}`}>
                            {stg.label}
                          </h5>
                          <p className="text-[10px] text-neutral-400 mt-0.5 max-w-[130px] md:mx-auto">
                            {stg.desc}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Consignment Items & Destination */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Destination Details */}
              <div className="p-6 rounded-xl bg-[#0e0c08] border border-[#2b2214] space-y-3 text-xs">
                <span className="text-[10px] uppercase text-[#D6B16D] font-bold tracking-wider block">
                  Delivery Destination
                </span>
                <div className="flex items-start gap-2.5 text-neutral-300">
                  <MapPin className="w-4 h-4 text-[#D6B16D] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-medium">{order.shippingAddress}</p>
                    <p className="text-neutral-400">City: {order.city}, Pakistan</p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 text-neutral-300 pt-2 border-t border-[#1e170e]">
                  <Phone className="w-4 h-4 text-[#D6B16D] shrink-0" />
                  <span>Recipient Contact: {order.customerPhone}</span>
                </div>
              </div>

              {/* Order Items */}
              <div className="p-6 rounded-xl bg-[#0e0c08] border border-[#2b2214] space-y-3 text-xs">
                <span className="text-[10px] uppercase text-[#D6B16D] font-bold tracking-wider block">
                  Enclosed Masterworks ({order.items.length})
                </span>
                <div className="space-y-2">
                  {order.items.map((item, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img src={item.image} alt={item.name} className="w-8 h-8 rounded object-cover" />
                        <div>
                          <span className="text-white font-medium block truncate max-w-[180px]">{item.name}</span>
                          <span className="text-[10px] text-neutral-400">Qty: {item.quantity}</span>
                        </div>
                      </div>
                      <span className="font-mono text-[#D6B16D]">{formatPKR(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 border-t border-[#1e170e] flex justify-between font-semibold">
                  <span className="text-white">Insured Total</span>
                  <span className="font-mono text-white">{formatPKR(order.total)}</span>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
