import React, { useState, useMemo } from 'react';
import { 
  Filter, 
  ArrowUpDown, 
  Search, 
  Sparkles, 
  RotateCcw, 
  SlidersHorizontal,
  X
} from 'lucide-react';
import { useProducts } from '../../context/ProductContext';
import { ProductCard } from './ProductCard';
import { Product, ProductCategory } from '../../types';

interface ShopPageProps {
  onQuickView: (product: Product) => void;
  initialCategory?: ProductCategory | null;
  initialFilter?: 'new' | 'all' | null;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  onQuickView,
  initialCategory = null,
  initialFilter = null
}) => {
  const { products, selectedCategory, setSelectedCategory } = useProducts();

  // Active filters
  const [activeCategory, setActiveCategory] = useState<ProductCategory | 'all'>(
    initialCategory || (selectedCategory as any) || 'all'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');
  const [priceRange, setPriceRange] = useState<'all' | 'under4k' | '4k-8k' | 'above8k'>('all');
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Sync when initialCategory prop changes
  React.useEffect(() => {
    if (initialCategory) {
      setActiveCategory(initialCategory);
    }
  }, [initialCategory]);

  const categories: (ProductCategory | 'all')[] = [
    'all',
    'Customised Nikkah Essentials',
    'Watches',
    'Handbags',
    'Bangles',
    'Stainless Steel Jewellery'
  ];

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        // Category filter
        if (activeCategory !== 'all') {
          if (p.category !== activeCategory) {
            if (activeCategory === 'Watches' && (p.category === "Men's Watches" || p.category === "Women's Watches")) {
              // Match
            } else {
              return false;
            }
          }
        }

        // New in filter
        if (initialFilter === 'new' && !p.isNewArrival) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchSku = p.sku.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          if (!matchName && !matchSku && !matchDesc) return false;
        }

        // Price range
        const effPrice = p.salePrice ?? p.price;
        if (priceRange === 'under4k' && effPrice >= 4000) return false;
        if (priceRange === '4k-8k' && (effPrice < 4000 || effPrice > 8000)) return false;
        if (priceRange === 'above8k' && effPrice <= 8000) return false;

        // In Stock
        if (onlyInStock && p.stock <= 0) return false;

        return true;
      })
      .sort((a, b) => {
        const priceA = a.salePrice ?? a.price;
        const priceB = b.salePrice ?? b.price;
        if (sortBy === 'price-asc') return priceA - priceB;
        if (sortBy === 'price-desc') return priceB - priceA;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        return (b.rating || 5) - (a.rating || 5);
      });
  }, [products, activeCategory, searchQuery, sortBy, priceRange, selectedPurity, onlyInStock, initialFilter]);

  const handleResetFilters = () => {
    setActiveCategory('all');
    setSelectedCategory(null);
    setSearchQuery('');
    setSortBy('featured');
    setPriceRange('all');
    setSelectedPurity('all');
    setOnlyInStock(false);
  };

  return (
    <div className="py-12 px-6 lg:px-12 bg-[#080808] min-h-screen">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-[#D6B16D] font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#D6B16D]" />
            <span>High Jewellery Catalogue</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-serif text-white tracking-wide">
            {activeCategory === 'all' ? (
              <>Haute <span className="italic font-serif gold-gradient-text">Collections</span></>
            ) : (
              <span className="gold-gradient-text">{activeCategory}</span>
            )}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 font-light">
            Every piece is certified hallmarked gold and certified conflict-free diamonds, handcrafted in our master ateliers.
          </p>
        </div>

        {/* Category Pills Bar */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setActiveCategory(cat);
                setSelectedCategory(cat === 'all' ? null : cat);
              }}
              className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider font-medium whitespace-nowrap transition-all border ${
                activeCategory === cat
                  ? 'bg-[#D6B16D] text-black border-[#D6B16D] font-semibold shadow-md shadow-[#D6B16D]/15'
                  : 'bg-[#110e09] text-neutral-300 border-[#261f13] hover:border-[#D6B16D]'
              }`}
            >
              {cat === 'all' ? 'All Pieces' : cat}
            </button>
          ))}
        </div>

        {/* Filter and Search Control Bar */}
        <div className="p-4 rounded-xl bg-[#0e0c08] border border-[#241c11] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by piece title or SKU..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#141009] border border-[#2d2214] rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#D6B16D]"
            />
          </div>

          <div className="flex items-center gap-3">
            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 bg-[#141009] border border-[#2d2214] rounded-lg px-3 py-1.5 text-xs text-white">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#D6B16D]" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
              >
                <option value="featured">Most Coveted</option>
                <option value="newest">Newest Additions</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>

            {/* Mobile Filter Button */}
            <button
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              className="px-3.5 py-1.5 rounded-lg bg-[#141009] border border-[#2d2214] text-xs text-neutral-200 hover:text-white flex items-center gap-1.5"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#D6B16D]" />
              <span>Filters</span>
            </button>
          </div>

        </div>

        {/* Collapsible Filter Tray */}
        {mobileFilterOpen && (
          <div className="p-5 rounded-xl bg-[#0f0c08] border border-[#2b2114] space-y-4 animate-fadeIn text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-[#211a10]">
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#D6B16D]">
                Refine Selection
              </span>
              <button onClick={() => setMobileFilterOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {/* Price Tier */}
              <div>
                <label className="block text-neutral-400 mb-2 font-medium">Price Range (PKR)</label>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                    <input
                      type="radio"
                      name="price"
                      checked={priceRange === 'all'}
                      onChange={() => setPriceRange('all')}
                      className="accent-[#D6B16D]"
                    />
                    <span>All Price Points</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                    <input
                      type="radio"
                      name="price"
                      checked={priceRange === 'under4k'}
                      onChange={() => setPriceRange('under4k')}
                      className="accent-[#D6B16D]"
                    />
                    <span>Under ₨ 4,000</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                    <input
                      type="radio"
                      name="price"
                      checked={priceRange === '4k-8k'}
                      onChange={() => setPriceRange('4k-8k')}
                      className="accent-[#D6B16D]"
                    />
                    <span>₨ 4,000 – ₨ 8,000</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                    <input
                      type="radio"
                      name="price"
                      checked={priceRange === 'above8k'}
                      onChange={() => setPriceRange('above8k')}
                      className="accent-[#D6B16D]"
                    />
                    <span>Above ₨ 8,000</span>
                  </label>
                </div>
              </div>

              {/* Special Features & Customization */}
              <div>
                <label className="block text-neutral-400 mb-2 font-medium">Bespoke Features</label>
                <div className="space-y-2 text-neutral-300">
                  <div className="p-2.5 rounded-lg bg-[#141009] border border-[#2d2214] text-[11px] text-neutral-400 space-y-1">
                    <span className="text-[#D6B16D] font-semibold block">✨ Custom Nikkah Personalization</span>
                    <span>Free bride & groom name engraving on Nikkah pens, boxes & platters.</span>
                  </div>
                  <div className="p-2 rounded-lg bg-[#141009] border border-[#2d2214] text-[11px] text-[#D6B16D]">
                    🚚 Free Delivery unlocked on all orders over ₨ 5,000!
                  </div>
                </div>
              </div>

              {/* In-Stock Switch */}
              <div className="space-y-4">
                <div>
                  <label className="block text-neutral-400 mb-2 font-medium">Availability</label>
                  <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                    <input
                      type="checkbox"
                      checked={onlyInStock}
                      onChange={(e) => setOnlyInStock(e.target.checked)}
                      className="accent-[#D6B16D]"
                    />
                    <span>Show In-Stock Ready Pieces Only</span>
                  </label>
                </div>

                <div>
                  <button
                    onClick={handleResetFilters}
                    className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-[#D6B16D] transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset All Filters</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Product Count & Status */}
        <div className="flex items-center justify-between text-xs text-neutral-400 border-b border-[#1c160e] pb-3">
          <span>Showing <strong>{filteredProducts.length}</strong> masterworks</span>
          {onlyInStock && <span className="text-emerald-400">• Filtering In-Stock only</span>}
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center space-y-4">
            <p className="text-base font-serif text-white">No creations match the selected filters.</p>
            <p className="text-xs text-neutral-400 max-w-sm mx-auto">
              Please adjust your price range or category criteria to view our handcrafted inventory.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-6 py-2.5 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded hover:bg-[#F4E0A5] transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={onQuickView}
              />
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
