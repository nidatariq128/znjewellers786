import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Diamond, Gem } from 'lucide-react';
import { ProductCategory } from '../../types';

interface HeroProps {
  onShopCollection: () => void;
  onExploreMore: () => void;
  onSelectCategory: (category: ProductCategory) => void;
  onQuickViewHeroProduct: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onShopCollection,
  onExploreMore,
  onSelectCategory,
  onQuickViewHeroProduct
}) => {
  return (
    <section className="relative w-full overflow-hidden bg-[#080808] border-b border-[#221c13]">
      
      {/* Subtle luxury ambient lighting */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#D6B16D]/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-[30rem] h-[30rem] bg-[#A67C2E]/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16 lg:py-24 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center min-h-[82vh]">
        
        {/* Left Editorial Copy (Columns 1-7) */}
        <div className="lg:col-span-7 space-y-8 z-10">
          
          {/* Tagline */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#18140d] border border-[#3b301c]">
            <Sparkles className="w-3.5 h-3.5 text-[#D6B16D]" />
            <span className="text-[11px] uppercase tracking-[0.28em] text-[#D6B16D] font-medium">
              Timeless Elegance. Crafted For You.
            </span>
          </div>

          {/* Heading */}
          <div className="space-y-3">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif text-white font-normal tracking-tight leading-[1.12]">
              Bespoke Nikkah Essentials,{' '}
              <span className="gold-gradient-text italic font-serif">Watches</span> & Handbags.
            </h1>
          </div>

          {/* Luxury Brand Description */}
          <p className="text-sm sm:text-base text-neutral-300 font-light leading-relaxed max-w-xl">
            Discover bespoke customized Nikkah pen boxes, signature signing pens, and engraved mirror platters, alongside luxury timepieces, bridal bangles & kadas, designer handbags, and waterproof stainless steel jewellery.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
            <button
              onClick={onShopCollection}
              className="px-8 py-4 bg-gradient-to-r from-[#D6B16D] via-[#F4E0A5] to-[#C29B53] text-black text-xs uppercase tracking-[0.2em] font-semibold rounded hover:shadow-[0_0_30px_rgba(214,177,109,0.35)] transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer"
            >
              <span>Explore All Collections</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreMore}
              className="px-8 py-4 bg-[#120f0a] border border-[#3d321d] text-neutral-200 text-xs uppercase tracking-[0.2em] font-medium rounded hover:border-[#D6B16D] hover:text-[#D6B16D] transition-all duration-300 flex items-center justify-center cursor-pointer"
            >
              Our Story
            </button>
          </div>

          {/* Trust Highlights */}
          <div className="pt-8 border-t border-[#1f1911] grid grid-cols-3 gap-6 max-w-lg">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <Sparkles className="w-4 h-4 text-[#D6B16D]" />
                <span>Nikkah Decor</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Custom Names & Dates</p>
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <ShieldCheck className="w-4 h-4 text-[#D6B16D]" />
                <span>Watches & Bangles</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Bridal & Formal Wear</p>
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#D6B16D] font-serif font-medium">
                <Gem className="w-4 h-4 text-[#D6B16D]" />
                <span>Anti-Tarnish</span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">100% Waterproof Steel</p>
            </div>
          </div>

        </div>

        {/* Right Visual Composition (Columns 8-12) */}
        <div className="lg:col-span-5 relative flex items-center justify-center">
          
          {/* Framed Editorial Visual */}
          <div className="relative w-full max-w-md aspect-[4/5] rounded-xl overflow-hidden border border-[#3b301c] shadow-[0_20px_50px_rgba(0,0,0,0.9)] group">
            
            <img
              src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=85"
              alt="ZN JEWELLERS Customised Nikkah Essentials & Luxury Collection"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-95"
            />

            {/* Gradient Overlays */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-transparent to-transparent opacity-70" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080808]/40 via-transparent to-[#080808]/20" />

            {/* Floating Interactive Product Card */}
            <div 
              onClick={onQuickViewHeroProduct}
              className="absolute bottom-6 left-6 right-6 p-4 rounded-lg bg-[#0e0c08]/90 backdrop-blur-md border border-[#4a3d24] shadow-2xl flex items-center justify-between cursor-pointer hover:border-[#D6B16D] transition-all group/card"
            >
              <div>
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-[#D6B16D] font-medium">
                  <Sparkles className="w-3 h-3" />
                  <span>Custom Bridal Creation</span>
                </div>
                <h4 className="text-sm font-serif font-semibold text-white mt-0.5 group-hover/card:text-[#D6B16D] transition-colors">
                  Mirrored Customised Nikkah Platter
                </h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs font-semibold text-white font-mono">₨ 7,900</span>
                  <span className="text-[11px] text-neutral-400 line-through font-mono">₨ 8,500</span>
                </div>
              </div>

              <div className="w-9 h-9 rounded-full bg-[#D6B16D] text-black flex items-center justify-center shrink-0 group-hover/card:scale-110 transition-transform">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            {/* Gold Corner Accents */}
            <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-[#D6B16D]/70 pointer-events-none" />
            <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-[#D6B16D]/70 pointer-events-none" />
            <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-[#D6B16D]/70 pointer-events-none" />
            <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-[#D6B16D]/70 pointer-events-none" />

          </div>

        </div>

      </div>

    </section>
  );
};
