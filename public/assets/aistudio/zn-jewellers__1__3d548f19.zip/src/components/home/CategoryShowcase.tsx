import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { CATEGORIES_LIST } from '../../data/sampleProducts';
import { ProductCategory } from '../../types';

interface CategoryShowcaseProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export const CategoryShowcase: React.FC<CategoryShowcaseProps> = ({ onSelectCategory }) => {
  return (
    <section className="py-20 px-6 lg:px-12 bg-[#080808]">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-[#D6B16D] font-medium">
            <Sparkles className="w-3 h-3" />
            <span>Curated Collections</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif text-white tracking-wide">
            Shop By <span className="italic font-serif gold-gradient-text">Category</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light">
            Explore our curated realms: Customised Nikkah Essentials (Pen, Box, Platter), Luxury Watches, Designer Handbags, Traditional Bangles, and Waterproof Stainless Steel Jewellery.
          </p>
        </div>

        {/* 6 Category Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {CATEGORIES_LIST.map((cat) => (
            <div
              key={cat.name}
              onClick={() => onSelectCategory(cat.name as ProductCategory)}
              className="group relative h-80 sm:h-96 rounded-xl overflow-hidden border border-[#261f14] hover:border-[#D6B16D]/80 transition-all duration-500 cursor-pointer bg-[#0e0c09] shadow-lg flex flex-col justify-end p-6"
            >
              {/* Background Photography */}
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 brightness-75 group-hover:brightness-90"
              />

              {/* Gradient Dark Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-[#080808]/50 to-transparent opacity-90 group-hover:opacity-75 transition-opacity" />

              {/* Content Overlay */}
              <div className="relative z-10 space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                <span className="text-[10px] uppercase tracking-[0.25em] text-[#D6B16D] font-medium">
                  Collection
                </span>
                <h3 className="text-2xl font-serif font-medium text-white group-hover:text-[#D6B16D] transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs text-neutral-300 font-light line-clamp-2">
                  {cat.description}
                </p>

                <div className="pt-2 flex items-center gap-2 text-xs font-semibold text-[#D6B16D] uppercase tracking-wider group-hover:text-[#F4E0A5]">
                  <span>Discover Pieces</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>

              {/* Corner Gold Flourish */}
              <div className="absolute top-4 right-4 w-6 h-6 rounded-full border border-[#D6B16D]/40 flex items-center justify-center text-[#D6B16D] opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowRight className="w-3 h-3" />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
