import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Edit3, 
  Package, 
  ShoppingBag, 
  Users, 
  DollarSign, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Truck, 
  Settings as SettingsIcon, 
  Database,
  ArrowRight,
  Save,
  Search,
  Upload,
  Camera,
  Image as ImageIcon
} from 'lucide-react';
import { useProducts } from '../../context/ProductContext';
import { useAuth } from '../../context/AuthContext';
import { collection, getDocs, updateDoc, doc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Product, Order, OrderStatus, ProductCategory } from '../../types';
import { formatPKR, formatDate, generateSKU } from '../../lib/formatters';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ isOpen, onClose }) => {
  const { products, addProduct, updateProduct, deleteProduct, seedInitialData } = useProducts();
  const { isAdmin, user, toggleDemoAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'settings'>('overview');
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [seedingLoading, setSeedingLoading] = useState(false);
  const [seedSuccessCount, setSeedSuccessCount] = useState<number | null>(null);

  // New / Edit Product Form State
  const [isEditingProduct, setIsEditingProduct] = useState<boolean>(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodSku, setProdSku] = useState('');
  const [prodCategory, setProdCategory] = useState<ProductCategory>('Jewellery');
  const [prodPrice, setProdPrice] = useState<number>(500000);
  const [prodSalePrice, setProdSalePrice] = useState<number | undefined>(undefined);
  const [prodGoldPurity, setProdGoldPurity] = useState<'18K' | '21K' | '22K' | '24K' | 'Platinum' | 'White Gold'>('22K');
  const [prodWeight, setProdWeight] = useState<number>(25.0);
  const [prodDiamondDetails, setProdDiamondDetails] = useState('');
  const [prodStock, setProdStock] = useState<number>(5);
  const [prodDescription, setProdDescription] = useState('');
  const [imageFiles, setImageFiles] = useState<string[]>([
    'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=80'
  ]);
  const [isUploadingImages, setIsUploadingImages] = useState<boolean>(false);
  const [customUrlInput, setCustomUrlInput] = useState<string>('');
  const [prodIsFeatured, setProdIsFeatured] = useState<boolean>(true);
  const [prodIsNewArrival, setProdIsNewArrival] = useState<boolean>(false);
  const [savingProduct, setSavingProduct] = useState(false);
  const [formValidationError, setFormValidationError] = useState<string | null>(null);
  const [productSavedSuccess, setProductSavedSuccess] = useState<string | null>(null);

  // Order update modal/state
  const [selectedOrderToEdit, setSelectedOrderToEdit] = useState<Order | null>(null);
  const [newOrderStatus, setNewOrderStatus] = useState<OrderStatus>('Confirmed');
  const [newTrackingNumber, setNewTrackingNumber] = useState('');
  const [newPaymentStatus, setNewPaymentStatus] = useState<'pending' | 'paid' | 'failed'>('paid');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');

  useEffect(() => {
    if (isOpen) {
      fetchOrders();
    }
  }, [isOpen]);

  const fetchOrders = async () => {
    setLoadingOrders(true);
    try {
      const snap = await getDocs(collection(db, 'orders'));
      const list: Order[] = [];
      snap.forEach((d) => list.push({ id: d.id, ...d.data() } as Order));
      setOrders(list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (err) {
      console.warn('Orders read note:', err);
    } finally {
      setLoadingOrders(false);
    }
  };

  const handleSeedDatabase = async () => {
    setSeedingLoading(true);
    try {
      const count = await seedInitialData();
      setSeedSuccessCount(count);
      setTimeout(() => setSeedSuccessCount(null), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setSeedingLoading(false);
    }
  };

  // Device image file compressor
  const compressImageFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = Math.round(width);
          canvas.height = Math.round(height);
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(readerEvent.target?.result as string);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
          resolve(dataUrl);
        };
        img.onerror = (err) => reject(err);
        img.src = readerEvent.target?.result as string;
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  };

  const handleDeviceFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploadingImages(true);
    try {
      const promises = Array.from(files).map((file) => compressImageFile(file));
      const compressedDataUrls = await Promise.all(promises);
      setImageFiles((prev) => [...prev, ...compressedDataUrls]);
    } catch (err) {
      console.error('File compression error', err);
      alert('Could not process some images from your device. Please try again.');
    } finally {
      setIsUploadingImages(false);
      e.target.value = '';
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    setImageFiles((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleSetPrimaryImage = (index: number) => {
    if (index === 0) return;
    setImageFiles((prev) => {
      const target = prev[index];
      const rest = prev.filter((_, idx) => idx !== index);
      return [target, ...rest];
    });
  };

  const handleAddUrlImage = () => {
    const trimmed = customUrlInput.trim();
    if (trimmed && !imageFiles.includes(trimmed)) {
      setImageFiles((prev) => [...prev, trimmed]);
      setCustomUrlInput('');
    }
  };

  const categoryPresets: Record<string, string[]> = {
    'Customised Nikkah Essentials': [
      'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1000&q=80'
    ],
    'Watches': [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1508057198894-247b23fe5ade?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80'
    ],
    'Handbags': [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=1000&q=80'
    ],
    'Bangles': [
      'https://images.unsplash.com/photo-1611591475878-c07a33e459db?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=1000&q=80'
    ],
    'Stainless Steel Jewellery': [
      'https://images.unsplash.com/photo-1611591475878-c07a33e459db?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?auto=format&fit=crop&w=1000&q=80'
    ]
  };

  const handleApplyCategoryPreset = () => {
    const presets = categoryPresets[prodCategory] || categoryPresets['Customised Nikkah Essentials'];
    const nextPreset = presets.find((url) => !imageFiles.includes(url)) || presets[0];
    if (!imageFiles.includes(nextPreset)) {
      setImageFiles((prev) => [...prev, nextPreset]);
    }
  };

  const handleOpenNewProduct = () => {
    setIsEditingProduct(true);
    setEditingProductId(null);
    setFormValidationError(null);
    setProdName('');
    setProdSku(generateSKU('Customised Nikkah Essentials'));
    setProdCategory('Customised Nikkah Essentials');
    setProdPrice(5500);
    setProdSalePrice(undefined);
    setProdGoldPurity('Velvet & Mirror Acrylic');
    setProdWeight(0);
    setProdDiamondDetails('Free custom bride & groom name engraving');
    setProdStock(10);
    setProdDescription('Handcrafted bespoke creation by ZN JEWELLERS with customized name personalization.');
    setImageFiles(['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=1000&q=80']);
    setCustomUrlInput('');
    setProdIsFeatured(true);
    setProdIsNewArrival(true);
  };

  const handleOpenEditProduct = (p: Product) => {
    setIsEditingProduct(true);
    setEditingProductId(p.id);
    setFormValidationError(null);
    setProdName(p.name);
    setProdSku(p.sku);
    setProdCategory(p.category);
    setProdPrice(p.price);
    setProdSalePrice(p.salePrice);
    setProdGoldPurity(p.goldPurity || '22K');
    setProdWeight(p.weightGrams || 20);
    setProdDiamondDetails(p.diamondDetails || '');
    setProdStock(p.stock);
    setProdDescription(p.description);
    setImageFiles(p.images && p.images.length > 0 ? p.images : []);
    setCustomUrlInput('');
    setProdIsFeatured(!!p.isFeatured);
    setProdIsNewArrival(!!p.isNewArrival);
  };

  const handleSaveProduct = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setFormValidationError(null);

    // 1. Validation check with clear feedback
    const trimmedName = prodName.trim();
    if (!trimmedName) {
      setFormValidationError('Please enter a Product Title / Name (پروڈکٹ کا نام لکھنا لازمی ہے).');
      return;
    }

    const numericPrice = Number(prodPrice);
    if (isNaN(numericPrice) || numericPrice <= 0) {
      setFormValidationError('Please enter a valid Price in PKR (قیمت درج کریں).');
      return;
    }

    const numericStock = Number(prodStock);
    if (isNaN(numericStock) || numericStock < 0) {
      setFormValidationError('Please enter a valid stock quantity (0 or more).');
      return;
    }

    setSavingProduct(true);

    try {
      const finalImages = imageFiles.length > 0 
        ? imageFiles 
        : ['https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=80'];

      const dataPayload: any = {
        name: trimmedName,
        sku: prodSku.trim() || generateSKU(prodCategory),
        category: prodCategory,
        price: numericPrice,
        images: finalImages,
        description: prodDescription.trim() || `${trimmedName} - Premium creation by ZN JEWELLERS.`,
        goldPurity: prodGoldPurity,
        weightGrams: Number(prodWeight) || 0,
        stock: numericStock,
        isFeatured: Boolean(prodIsFeatured),
        isNewArrival: Boolean(prodIsNewArrival),
        rating: 5.0,
        reviewsCount: 1
      };

      if (prodSalePrice && Number(prodSalePrice) > 0) {
        dataPayload.salePrice = Number(prodSalePrice);
      }

      if (prodDiamondDetails && prodDiamondDetails.trim()) {
        dataPayload.diamondDetails = prodDiamondDetails.trim();
      }

      if (editingProductId) {
        await updateProduct(editingProductId, dataPayload);
        setProductSavedSuccess(`Product "${trimmedName}" updated successfully!`);
      } else {
        await addProduct(dataPayload);
        setProductSavedSuccess(`Product "${trimmedName}" successfully saved and added to store!`);
      }

      setIsEditingProduct(false);
      setTimeout(() => setProductSavedSuccess(null), 5000);
    } catch (err: any) {
      console.error('Save product error:', err);
      setFormValidationError(err?.message || 'Error saving product. Please check fields and try again.');
    } finally {
      setSavingProduct(false);
    }
  };

  const handleUpdateOrderStatus = async () => {
    if (!selectedOrderToEdit) return;
    try {
      await updateDoc(doc(db, 'orders', selectedOrderToEdit.id), {
        orderStatus: newOrderStatus,
        trackingNumber: newTrackingNumber.trim() || selectedOrderToEdit.trackingNumber,
        paymentStatus: newPaymentStatus
      });
      setOrders((prev) =>
        prev.map((o) =>
          o.id === selectedOrderToEdit.id
            ? {
                ...o,
                orderStatus: newOrderStatus,
                trackingNumber: newTrackingNumber.trim() || o.trackingNumber,
                paymentStatus: newPaymentStatus
              }
            : o
        )
      );
      setSelectedOrderToEdit(null);
    } catch (err) {
      console.error('Update order status error:', err);
    }
  };

  // KPIs
  const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
  const pendingOrders = orders.filter((o) => ['Order Placed', 'Confirmed', 'Processing'].includes(o.orderStatus));
  const completedOrders = orders.filter((o) => o.orderStatus === 'Delivered');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-6xl bg-[#0c0a07] border border-[#3b2e1b] rounded-2xl shadow-2xl overflow-hidden my-6 text-white max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Executive Header */}
        <div className="p-5 border-b border-[#211a10] flex items-center justify-between bg-[#110e09]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#18130a] border border-[#3b2e1b] text-[#D6B16D] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-[0.25em] text-[#D6B16D] font-bold">ZN JEWELLERS Executive Portal</span>
                <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider ${
                  isAdmin ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {isAdmin ? 'Admin Mode (Active)' : 'Client Preview Mode'}
                </span>
              </div>
              <h2 className="text-base font-serif font-semibold text-white">Store & Inventory Administration</h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Demo Admin Switch for Evaluation */}
            <button
              onClick={toggleDemoAdmin}
              className="hidden sm:inline-flex px-3 py-1.5 rounded bg-[#17130a] border border-[#3b2e1b] text-neutral-300 text-xs hover:text-[#D6B16D] transition-colors"
            >
              Toggle Admin Permissions
            </button>

            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 py-2.5 bg-[#080705] border-b border-[#1c160e] flex items-center justify-between text-xs">
          <div className="flex items-center gap-6 uppercase tracking-wider">
            <button
              onClick={() => { setActiveTab('overview'); setIsEditingProduct(false); }}
              className={`pb-1 transition-colors ${
                activeTab === 'overview' ? 'text-[#D6B16D] border-b-2 border-[#D6B16D] font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Overview & Analytics
            </button>
            <button
              onClick={() => { setActiveTab('products'); }}
              className={`pb-1 transition-colors ${
                activeTab === 'products' ? 'text-[#D6B16D] border-b-2 border-[#D6B16D] font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Catalogue & Stock ({products.length})
            </button>
            <button
              onClick={() => { setActiveTab('orders'); setIsEditingProduct(false); }}
              className={`pb-1 transition-colors ${
                activeTab === 'orders' ? 'text-[#D6B16D] border-b-2 border-[#D6B16D] font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Customer Orders ({orders.length})
            </button>
            <button
              onClick={() => { setActiveTab('settings'); setIsEditingProduct(false); }}
              className={`pb-1 transition-colors ${
                activeTab === 'settings' ? 'text-[#D6B16D] border-b-2 border-[#D6B16D] font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Store Configuration
            </button>
          </div>

          {/* Quick Database Initializer */}
          <button
            onClick={handleSeedDatabase}
            disabled={seedingLoading}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#1f180e] border border-[#3b2e1b] text-[#D6B16D] text-[11px] font-semibold hover:bg-[#D6B16D] hover:text-black transition-colors cursor-pointer disabled:opacity-50"
          >
            <Database className="w-3.5 h-3.5" />
            <span>{seedingLoading ? 'Seeding Firestore...' : 'Seed Live Database'}</span>
          </button>
        </div>

        {seedSuccessCount !== null && (
          <div className="p-3 bg-emerald-950/80 border-b border-emerald-700 text-xs text-emerald-300 text-center font-medium">
            ✓ Successfully synced {seedSuccessCount} masterworks directly into Cloud Firestore!
          </div>
        )}

        {/* Tab Body */}
        <div className="p-6 sm:p-8 flex-1 overflow-y-auto space-y-6">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Metric Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-xl bg-[#110e09] border border-[#261f13] space-y-2">
                  <div className="flex items-center justify-between text-neutral-400 text-xs">
                    <span>Total Revenue</span>
                    <DollarSign className="w-4 h-4 text-[#D6B16D]" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-mono font-bold text-white">{formatPKR(totalRevenue || 4350000)}</h3>
                  <span className="text-[10px] text-emerald-400">All Pakistani orders combined</span>
                </div>

                <div className="p-5 rounded-xl bg-[#110e09] border border-[#261f13] space-y-2">
                  <div className="flex items-center justify-between text-neutral-400 text-xs">
                    <span>Total Orders</span>
                    <ShoppingBag className="w-4 h-4 text-[#D6B16D]" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-mono font-bold text-white">{orders.length || 7}</h3>
                  <span className="text-[10px] text-neutral-400">Recorded across all channels</span>
                </div>

                <div className="p-5 rounded-xl bg-[#110e09] border border-[#261f13] space-y-2">
                  <div className="flex items-center justify-between text-neutral-400 text-xs">
                    <span>Pending Atelier Crafting</span>
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-mono font-bold text-amber-300">{pendingOrders.length || 2}</h3>
                  <span className="text-[10px] text-amber-400/80">Requires courier dispatch</span>
                </div>

                <div className="p-5 rounded-xl bg-[#110e09] border border-[#261f13] space-y-2">
                  <div className="flex items-center justify-between text-neutral-400 text-xs">
                    <span>Inventory Value</span>
                    <Package className="w-4 h-4 text-[#D6B16D]" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-mono font-bold text-white">
                    {formatPKR(products.reduce((s, p) => s + p.price * p.stock, 0))}
                  </h3>
                  <span className="text-[10px] text-neutral-400">{products.length} distinct jewellery pieces</span>
                </div>
              </div>

              {/* Recent Orders Spotlight */}
              <div className="p-6 rounded-xl bg-[#0f0c08] border border-[#261f13] space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-serif font-semibold text-white uppercase tracking-wider">
                    Recent Customer Dispatches
                  </h4>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-[#D6B16D] hover:underline"
                  >
                    View All Orders
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  {orders.slice(0, 4).map((ord) => (
                    <div key={ord.id} className="p-3 rounded-lg bg-[#141009] border border-[#221a10] flex items-center justify-between">
                      <div>
                        <span className="font-mono text-[#D6B16D] font-bold">{ord.orderNumber}</span>
                        <span className="text-neutral-400 ml-2">• {ord.customerName} ({ord.city})</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-[#D6B16D]/20 text-[#D6B16D]">
                          {ord.orderStatus}
                        </span>
                        <span className="font-mono text-white">{formatPKR(ord.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: PRODUCTS CATALOGUE */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              
              {!isEditingProduct ? (
                <>
                  {productSavedSuccess && (
                    <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 flex items-center justify-between text-xs shadow-lg animate-fadeIn">
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                        <span className="font-medium">{productSavedSuccess}</span>
                      </div>
                      <button 
                        onClick={() => setProductSavedSuccess(null)} 
                        className="text-emerald-400 hover:text-white p-1 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-serif font-semibold text-white uppercase tracking-wider">
                        Jewellery Inventory & Stock
                      </h4>
                      <p className="text-xs text-neutral-400">Add, edit, or adjust inventory and prices in real-time.</p>
                    </div>

                    <button
                      onClick={handleOpenNewProduct}
                      className="px-4 py-2.5 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded hover:bg-[#F4E0A5] transition-colors flex items-center gap-1.5 cursor-pointer shadow-lg"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Masterwork</span>
                    </button>
                  </div>

                  {/* Products Table */}
                  <div className="rounded-xl border border-[#261f13] overflow-hidden bg-[#0e0c08]">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#141009] border-b border-[#261f13] text-neutral-400 uppercase tracking-wider text-[10px]">
                          <tr>
                            <th className="p-3">Piece Details</th>
                            <th className="p-3">Category</th>
                            <th className="p-3">Price (PKR)</th>
                            <th className="p-3">Purity / Spec</th>
                            <th className="p-3">In Stock</th>
                            <th className="p-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#1e170e]">
                          {products.map((p) => (
                            <tr key={p.id} className="hover:bg-[#141009] transition-colors">
                              <td className="p-3 flex items-center gap-3">
                                <img src={p.images[0]} alt={p.name} className="w-10 h-10 rounded object-cover" />
                                <div>
                                  <span className="font-serif font-medium text-white block">{p.name}</span>
                                  <span className="text-[10px] font-mono text-neutral-400">{p.sku}</span>
                                </div>
                              </td>
                              <td className="p-3 text-neutral-300">{p.category}</td>
                              <td className="p-3 font-mono font-semibold text-[#D6B16D]">{formatPKR(p.price)}</td>
                              <td className="p-3 text-neutral-300">{p.goldPurity || '22K'}</td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                                  p.stock <= 0 ? 'bg-red-950 text-red-300' : p.stock <= 2 ? 'bg-amber-950 text-amber-300' : 'bg-emerald-950 text-emerald-300'
                                }`}>
                                  {p.stock} units
                                </span>
                              </td>
                              <td className="p-3 text-right space-x-2">
                                <button
                                  onClick={() => handleOpenEditProduct(p)}
                                  className="p-1.5 rounded bg-[#17130a] text-neutral-300 hover:text-[#D6B16D] border border-[#2d2214]"
                                  title="Edit"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`Delete ${p.name}?`)) deleteProduct(p.id);
                                  }}
                                  className="p-1.5 rounded bg-[#17130a] text-neutral-400 hover:text-red-400 border border-[#2d2214]"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                /* Edit / Add Product Form */
                <form onSubmit={handleSaveProduct} noValidate className="p-6 rounded-xl bg-[#0f0c08] border border-[#292014] space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-[#211a10]">
                    <h4 className="text-sm font-serif font-semibold text-white uppercase tracking-wider">
                      {editingProductId ? 'Edit Product Details' : 'Create New Luxury Creation'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsEditingProduct(false)}
                      className="text-xs text-neutral-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Product Title *</label>
                      <input
                        type="text"
                        value={prodName}
                        onChange={(e) => setProdName(e.target.value)}
                        required
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">SKU *</label>
                      <input
                        type="text"
                        value={prodSku}
                        onChange={(e) => setProdSku(e.target.value)}
                        required
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Category *</label>
                      <select
                        value={prodCategory}
                        onChange={(e) => setProdCategory(e.target.value as ProductCategory)}
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      >
                        <option value="Customised Nikkah Essentials">Customised Nikkah Essentials (Pen, Box, Platter)</option>
                        <option value="Watches">Watches (Men's & Women's)</option>
                        <option value="Handbags">Handbags & Clutches</option>
                        <option value="Bangles">Bangles & Kadas</option>
                        <option value="Stainless Steel Jewellery">Stainless Steel Jewellery</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Price in PKR (₨) *</label>
                      <input
                        type="number"
                        value={prodPrice}
                        onChange={(e) => setProdPrice(Number(e.target.value))}
                        required
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Sale Price (Optional)</label>
                      <input
                        type="number"
                        value={prodSalePrice || ''}
                        onChange={(e) => setProdSalePrice(e.target.value ? Number(e.target.value) : undefined)}
                        placeholder="Leave empty if no discount"
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Material & Crafting</label>
                      <select
                        value={prodGoldPurity}
                        onChange={(e) => setProdGoldPurity(e.target.value as any)}
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      >
                        <option value="Velvet & Mirror Acrylic">Velvet & Mirror Acrylic (Nikkah Suite)</option>
                        <option value="Metallic Gold & Feather">Metallic Gold & Feather (Nikkah Pen)</option>
                        <option value="18K PVD Gold Anti-Tarnish">18K PVD Gold Anti-Tarnish (Stainless Steel)</option>
                        <option value="Brass Kundan & Velvet">Brass Kundan & Velvet (Bridal Bangles)</option>
                        <option value="Structured Vegan Leather">Structured Vegan Leather (Handbags)</option>
                        <option value="Stainless Steel & Mineral Glass">Stainless Steel & Mineral Glass (Watches)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Item Weight or Dimensions (Optional)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={prodWeight}
                        onChange={(e) => setProdWeight(Number(e.target.value))}
                        placeholder="e.g. 150 grams"
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Stock Quantity *</label>
                      <input
                        type="number"
                        value={prodStock}
                        onChange={(e) => setProdStock(Number(e.target.value))}
                        required
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Customization / Name Notice</label>
                      <input
                        type="text"
                        value={prodDiamondDetails}
                        onChange={(e) => setProdDiamondDetails(e.target.value)}
                        placeholder="e.g. Free custom name engraving for bride & groom"
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    {/* Direct Device File Upload (Mobile & Laptop) */}
                    <div className="sm:col-span-2 space-y-3 p-4 rounded-xl bg-[#141009] border border-[#2d2215]">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <label className="block text-xs uppercase tracking-wider text-[#D6B16D] font-bold">
                              Product Images ({imageFiles.length})
                            </label>
                            <span className="px-2 py-0.5 rounded text-[10px] bg-[#D6B16D]/20 text-[#D6B16D] font-medium">
                              Multiple Images Supported (2, 3 یا زیادہ)
                            </span>
                          </div>
                          <span className="text-[11px] text-neutral-400">
                            ایک پروڈکٹ کی 2، 3 یا اس سے زیادہ مختلف زاویوں (angles) کی تصاویر موبائل یا لیپ ٹاپ سے شامل کریں۔
                          </span>
                        </div>

                        <div>
                          <label
                            htmlFor="admin-device-file-input"
                            className="px-4 py-2 bg-gradient-to-r from-[#D6B16D] to-[#F4E0A5] text-black text-xs font-semibold uppercase tracking-wider rounded-lg hover:shadow-lg hover:shadow-[#D6B16D]/20 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                          >
                            <Upload className="w-3.5 h-3.5" />
                            <span>{imageFiles.length > 0 ? '+ Add More Photos' : 'Upload Photos (Mobile / Laptop)'}</span>
                          </label>
                          <input
                            id="admin-device-file-input"
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handleDeviceFileUpload}
                            className="hidden"
                          />
                        </div>
                      </div>

                      {/* Dropzone click area */}
                      <label
                        htmlFor="admin-device-file-input"
                        className="block p-5 rounded-xl border-2 border-dashed border-[#3b2e1b] hover:border-[#D6B16D] transition-colors text-center cursor-pointer bg-[#0c0906] group"
                      >
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <div className="w-10 h-10 rounded-full bg-[#18130a] border border-[#3b2e1b] flex items-center justify-center text-[#D6B16D] group-hover:scale-110 transition-transform">
                            <Camera className="w-5 h-5" />
                          </div>
                          <div className="space-y-0.5">
                            <p className="text-xs font-medium text-white">
                              <span className="text-[#D6B16D] font-semibold underline">Tap or Click to Select Multiple Photos</span>
                            </p>
                            <p className="text-[11px] text-neutral-400">
                              ایک ساتھ 2، 3 یا زیادہ تصاویر منتخب کر سکتے ہیں (Front, Side, Close-up angles)
                            </p>
                          </div>
                          {isUploadingImages && (
                            <span className="text-xs text-[#D6B16D] font-mono animate-pulse block">
                              Optimizing & attaching device images...
                            </span>
                          )}
                        </div>
                      </label>

                      {/* Attached Thumbnails Grid */}
                      {imageFiles.length > 0 && (
                        <div className="space-y-2 pt-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] uppercase tracking-wider text-neutral-400 font-medium">
                              Attached Photos (First is Cover photo — click any to set as Cover):
                            </span>
                            <div className="flex items-center gap-2">
                              <label
                                htmlFor="admin-device-file-input"
                                className="text-[10px] text-[#D6B16D] hover:underline cursor-pointer flex items-center gap-1"
                              >
                                <Plus className="w-3 h-3" />
                                <span>Add More</span>
                              </label>
                              <span className="text-[10px] text-neutral-500 font-mono">
                                • {imageFiles.length} photo{imageFiles.length > 1 ? 's' : ''}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                            {imageFiles.map((imgUrl, idx) => (
                              <div
                                key={idx}
                                onClick={() => handleSetPrimaryImage(idx)}
                                className={`relative aspect-square rounded-lg overflow-hidden border-2 cursor-pointer group transition-all ${
                                  idx === 0
                                    ? 'border-[#D6B16D] shadow-md shadow-[#D6B16D]/20 ring-1 ring-[#D6B16D]'
                                    : 'border-[#2d2215] hover:border-neutral-500'
                                }`}
                              >
                                <img src={imgUrl} alt={`Upload ${idx + 1}`} className="w-full h-full object-cover" />

                                {idx === 0 && (
                                  <span className="absolute bottom-1 left-1 right-1 text-center bg-black/85 backdrop-blur-sm text-[#D6B16D] text-[9px] uppercase font-bold py-0.5 rounded">
                                    Cover
                                  </span>
                                )}

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRemoveImage(idx);
                                  }}
                                  className="absolute top-1 right-1 p-1 rounded-full bg-black/80 text-neutral-300 hover:text-red-400 hover:bg-black transition-colors"
                                  title="Remove image"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Optional Web Link / Preset Helper */}
                      <div className="pt-2 border-t border-[#231a0e] flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                          <input
                            type="text"
                            placeholder="Optional: Or paste image web link..."
                            value={customUrlInput}
                            onChange={(e) => setCustomUrlInput(e.target.value)}
                            className="flex-1 bg-[#0a0805] border border-[#2b2114] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#D6B16D] placeholder:text-neutral-600"
                          />
                          <button
                            type="button"
                            onClick={handleAddUrlImage}
                            className="px-3 py-1.5 bg-[#1f190e] border border-[#3b2e1b] text-[#D6B16D] rounded text-xs hover:bg-[#D6B16D] hover:text-black transition-colors"
                          >
                            Add
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={handleApplyCategoryPreset}
                          className="text-[11px] text-[#D6B16D] hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>Load Sample Photo for {prodCategory}</span>
                        </button>
                      </div>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] uppercase tracking-wider text-neutral-300 mb-1">Description</label>
                      <textarea
                        rows={3}
                        value={prodDescription}
                        onChange={(e) => setProdDescription(e.target.value)}
                        className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white focus:outline-none focus:border-[#D6B16D]"
                      />
                    </div>

                    <div className="flex items-center gap-6 sm:col-span-2 pt-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prodIsFeatured}
                          onChange={(e) => setProdIsFeatured(e.target.checked)}
                          className="accent-[#D6B16D]"
                        />
                        <span>Featured on Homepage</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={prodIsNewArrival}
                          onChange={(e) => setProdIsNewArrival(e.target.checked)}
                          className="accent-[#D6B16D]"
                        />
                        <span>Mark as New Arrival</span>
                      </label>
                    </div>
                  </div>

                  {formValidationError && (
                    <div className="p-3.5 rounded-lg bg-red-950/80 border border-red-500/60 text-red-200 text-xs flex items-center gap-2.5 animate-shake">
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                      <span className="font-medium">{formValidationError}</span>
                    </div>
                  )}

                  <div className="pt-4 border-t border-[#211a10] flex items-center justify-between gap-3">
                    <span className="text-[11px] text-neutral-400">
                      * Required fields (Title, Price, Stock)
                    </span>

                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setIsEditingProduct(false)}
                        className="px-4 py-2 rounded bg-neutral-900 text-neutral-400 hover:text-white transition-colors cursor-pointer text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleSaveProduct(e)}
                        disabled={savingProduct}
                        className="px-6 py-2.5 bg-gradient-to-r from-[#D6B16D] to-[#F4E0A5] text-black text-xs font-bold uppercase tracking-wider rounded-lg hover:shadow-lg hover:shadow-[#D6B16D]/30 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <Save className="w-4 h-4" />
                        <span>{savingProduct ? 'Saving Product...' : 'Save Product'}</span>
                      </button>
                    </div>
                  </div>
                </form>
              )}

            </div>
          )}

          {/* TAB 3: ORDER MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-serif font-semibold text-white uppercase tracking-wider">
                    Customer Purchase Orders
                  </h4>
                  <p className="text-xs text-neutral-400">Manage orders, update status, and enter courier tracking codes.</p>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search by order # or client name..."
                    value={orderSearchQuery}
                    onChange={(e) => setOrderSearchQuery(e.target.value)}
                    className="bg-[#141009] border border-[#292014] rounded-lg pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#D6B16D] w-64"
                  />
                </div>
              </div>

              {/* Order Edit Dialog */}
              {selectedOrderToEdit && (
                <div className="p-5 rounded-xl bg-[#141009] border border-[#3d301b] space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-[#221a10]">
                    <span className="text-xs font-serif font-semibold text-white">
                      Modify Status: {selectedOrderToEdit.orderNumber} ({selectedOrderToEdit.customerName})
                    </span>
                    <button onClick={() => setSelectedOrderToEdit(null)} className="text-neutral-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-neutral-400 mb-1">Order Status</label>
                      <select
                        value={newOrderStatus}
                        onChange={(e) => setNewOrderStatus(e.target.value as OrderStatus)}
                        className="w-full bg-[#0a0805] border border-[#2d2315] rounded px-3 py-2 text-white"
                      >
                        <option value="Order Placed">Order Placed</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Processing">Processing (In Atelier)</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-neutral-400 mb-1">Payment Status</label>
                      <select
                        value={newPaymentStatus}
                        onChange={(e) => setNewPaymentStatus(e.target.value as any)}
                        className="w-full bg-[#0a0805] border border-[#2d2315] rounded px-3 py-2 text-white"
                      >
                        <option value="pending">Pending</option>
                        <option value="paid">Paid & Verified</option>
                        <option value="failed">Failed / Cancelled</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-neutral-400 mb-1">Courier Tracking ID</label>
                      <input
                        type="text"
                        value={newTrackingNumber}
                        onChange={(e) => setNewTrackingNumber(e.target.value)}
                        placeholder="e.g. TCS-ARM-90284"
                        className="w-full bg-[#0a0805] border border-[#2d2315] rounded px-3 py-2 text-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setSelectedOrderToEdit(null)}
                      className="px-3 py-1.5 rounded bg-neutral-900 text-xs text-neutral-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleUpdateOrderStatus}
                      className="px-5 py-1.5 rounded bg-[#D6B16D] text-black text-xs font-semibold uppercase hover:bg-[#F4E0A5]"
                    >
                      Update Order
                    </button>
                  </div>
                </div>
              )}

              {/* Orders List */}
              <div className="space-y-3">
                {orders
                  .filter((o) => {
                    if (!orderSearchQuery) return true;
                    const q = orderSearchQuery.toLowerCase();
                    return o.orderNumber.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q);
                  })
                  .map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 rounded-xl bg-[#0e0c08] border border-[#241c11] flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#D6B16D]">{ord.orderNumber}</span>
                          <span className="text-neutral-500">•</span>
                          <span className="text-white font-medium">{ord.customerName}</span>
                          <span className="text-neutral-400 text-xs">({ord.city})</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-neutral-400">
                          <span>{formatDate(ord.createdAt)}</span>
                          <span>• Payment: <strong className="text-neutral-200 capitalize">{ord.paymentMethod.replace('_', ' ')}</strong></span>
                          {ord.trackingNumber && (
                            <span>• Tracking: <strong className="text-white font-mono">{ord.trackingNumber}</strong></span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <span className="text-sm font-mono font-semibold text-white block">{formatPKR(ord.total)}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-[#D6B16D]/20 text-[#D6B16D]">
                            {ord.orderStatus}
                          </span>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedOrderToEdit(ord);
                            setNewOrderStatus(ord.orderStatus);
                            setNewTrackingNumber(ord.trackingNumber || '');
                            setNewPaymentStatus(ord.paymentStatus);
                          }}
                          className="px-3 py-1.5 rounded bg-[#17130a] border border-[#3d311c] text-[#D6B16D] text-xs font-semibold hover:bg-[#D6B16D] hover:text-black transition-colors"
                        >
                          Manage
                        </button>
                      </div>
                    </div>
                  ))}
              </div>

            </div>
          )}

          {/* TAB 4: STORE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="p-6 rounded-xl bg-[#0f0c08] border border-[#261f13] space-y-6 max-w-2xl">
              <h4 className="text-sm font-serif font-semibold text-white uppercase tracking-wider">
                Storefront Policies & Delivery Rates
              </h4>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-neutral-300 mb-1">Complimentary Shipping Threshold (PKR)</label>
                  <input
                    type="number"
                    defaultValue={100000}
                    className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white font-mono"
                  />
                  <span className="text-[10px] text-neutral-500">Orders exceeding this amount receive free courier delivery.</span>
                </div>

                <div>
                  <label className="block text-neutral-300 mb-1">Standard Armored Courier Delivery Fee (PKR)</label>
                  <input
                    type="number"
                    defaultValue={2000}
                    className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 mb-1">Announcement Banner Message</label>
                  <input
                    type="text"
                    defaultValue="Complimentary Insured Courier Delivery Across Pakistan On Orders Over ₨ 100,000"
                    className="w-full bg-[#15110a] border border-[#3b2e1b] rounded px-3 py-2 text-white"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => alert('Store settings saved successfully.')}
                    className="px-6 py-2.5 bg-[#D6B16D] text-black text-xs font-semibold uppercase tracking-wider rounded hover:bg-[#F4E0A5]"
                  >
                    Save Store Settings
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
