import React, { createContext, useContext, useEffect, useState } from 'react';
import { collection, doc, getDocs, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Product } from '../types';
import { INITIAL_PRODUCTS, CATEGORIES_LIST } from '../data/sampleProducts';

interface ProductContextType {
  products: Product[];
  categories: typeof CATEGORIES_LIST;
  loading: boolean;
  selectedCategory: string | null;
  setSelectedCategory: (cat: string | null) => void;
  selectedProductForModal: Product | null;
  setSelectedProductForModal: (product: Product | null) => void;
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Promise<string>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  seedInitialData: () => Promise<number>;
  getProductById: (id: string) => Product | undefined;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('zn_custom_products');
      if (saved) {
        const customProds = (JSON.parse(saved) as Product[]).filter(
          (p) => (p.category as string) !== 'Jewellery'
        );
        const customIds = new Set(customProds.map((p) => p.id));
        const filteredInitial = INITIAL_PRODUCTS.filter((p) => !customIds.has(p.id));
        return [...customProds, ...filteredInitial];
      }
    } catch (e) {
      console.warn('LocalStorage read error:', e);
    }
    return INITIAL_PRODUCTS;
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProductForModal, setSelectedProductForModal] = useState<Product | null>(null);

  const fetchProducts = async () => {
    try {
      const colRef = collection(db, 'products');
      const snap = await getDocs(colRef);
      if (!snap.empty) {
        const firestoreList: Product[] = [];
        snap.forEach((d) => {
          const item = { id: d.id, ...d.data() } as Product;
          if ((item.category as string) !== 'Jewellery') {
            firestoreList.push(item);
          }
        });

        if (firestoreList.length > 0) {
          // Also merge any local custom products not yet in Firestore
          let merged = [...firestoreList];
          try {
            const saved = localStorage.getItem('zn_custom_products');
            if (saved) {
              const customProds = (JSON.parse(saved) as Product[]).filter(
                (p) => (p.category as string) !== 'Jewellery'
              );
              const fsIds = new Set(firestoreList.map((p) => p.id));
              const pendingUploads = customProds.filter((p) => !fsIds.has(p.id));
              merged = [...pendingUploads, ...firestoreList];
            }
          } catch {}

          setProducts(merged);
        } else {
          setProducts(INITIAL_PRODUCTS);
        }
      }
    } catch (err) {
      console.warn('Could not read from Firestore products collection, using local catalogue:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const addProduct = async (prodData: Omit<Product, 'id' | 'createdAt'>): Promise<string> => {
    const id = `zn-prod-${Date.now()}`;
    const newProduct: Product = {
      ...prodData,
      id,
      createdAt: new Date().toISOString()
    };

    // 1. Instantly update UI state so user sees it right away
    setProducts((prev) => [newProduct, ...prev]);

    // 2. Persist to localStorage backup
    try {
      const stored = localStorage.getItem('zn_custom_products');
      const list = stored ? (JSON.parse(stored) as Product[]) : [];
      localStorage.setItem('zn_custom_products', JSON.stringify([newProduct, ...list]));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }

    // 3. Persist to Cloud Firestore (strip undefined fields which Firestore rejects)
    try {
      const cleanProduct: Record<string, any> = {};
      for (const [k, v] of Object.entries(newProduct)) {
        if (v !== undefined) {
          cleanProduct[k] = v;
        }
      }
      await setDoc(doc(db, 'products', id), cleanProduct);
      console.log('[ZN Jewellers] Successfully wrote product to Cloud Firestore:', id);
    } catch (error) {
      console.warn('Firestore write notice (product safely stored in client state):', error);
    }

    return id;
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    // 1. Update UI state
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );

    // 2. Update localStorage
    try {
      const stored = localStorage.getItem('zn_custom_products');
      if (stored) {
        const list = JSON.parse(stored) as Product[];
        const updatedList = list.map((p) => (p.id === id ? { ...p, ...updates } : p));
        localStorage.setItem('zn_custom_products', JSON.stringify(updatedList));
      }
    } catch (e) {
      console.warn('LocalStorage update error:', e);
    }

    // 3. Update Firestore (strip undefined fields)
    try {
      const cleanUpdates: Record<string, any> = {};
      for (const [k, v] of Object.entries(updates)) {
        if (v !== undefined) {
          cleanUpdates[k] = v;
        }
      }
      await updateDoc(doc(db, 'products', id), cleanUpdates);
    } catch (error) {
      console.warn('Firestore update notice (product updated locally):', error);
    }
  };

  const deleteProduct = async (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));

    try {
      const stored = localStorage.getItem('zn_custom_products');
      if (stored) {
        const list = JSON.parse(stored) as Product[];
        const filtered = list.filter((p) => p.id !== id);
        localStorage.setItem('zn_custom_products', JSON.stringify(filtered));
      }
    } catch (e) {
      console.warn('LocalStorage delete error:', e);
    }

    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (error) {
      console.warn('Firestore delete error:', error);
    }
  };

  const seedInitialData = async (): Promise<number> => {
    let count = 0;
    try {
      for (const item of INITIAL_PRODUCTS) {
        await setDoc(doc(db, 'products', item.id), item);
        count++;
      }
      await fetchProducts();
      return count;
    } catch (err) {
      console.error('Failed to seed products into Firestore:', err);
      throw err;
    }
  };

  const getProductById = (id: string) => {
    return products.find((p) => p.id === id);
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        categories: CATEGORIES_LIST,
        loading,
        selectedCategory,
        setSelectedCategory,
        selectedProductForModal,
        setSelectedProductForModal,
        addProduct,
        updateProduct,
        deleteProduct,
        seedInitialData,
        getProductById
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};
