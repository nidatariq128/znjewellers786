import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { ProductProvider, useProducts } from './context/ProductContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/home/Hero';
import { CategoryShowcase } from './components/home/CategoryShowcase';
import { FeaturedCollection } from './components/home/FeaturedCollection';
import { NewArrivals } from './components/home/NewArrivals';
import { BrandStory } from './components/home/BrandStory';
import { PromotionalBanner } from './components/home/PromotionalBanner';
import { CustomerTestimonials } from './components/home/CustomerTestimonials';
import { ShopPage } from './components/shop/ShopPage';
import { ProductDetailModal } from './components/shop/ProductDetailModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutModal } from './components/checkout/CheckoutModal';
import { OrderTrackingView } from './components/tracking/OrderTrackingView';
import { SearchModal } from './components/search/SearchModal';
import { AccountModal } from './components/account/AccountModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ConciergeButton } from './components/common/ConciergeButton';
import { Product, ProductCategory } from './types';
import { useCart } from './context/CartContext';

function MainApp() {
  const { products, selectedProductForModal, setSelectedProductForModal } = useProducts();
  const { addToCart } = useCart();

  // Navigation views: 'home' | 'shop' | 'tracking'
  const [currentView, setCurrentView] = useState<'home' | 'shop' | 'tracking'>('home');
  const [shopCategory, setShopCategory] = useState<ProductCategory | null>(null);
  const [shopFilter, setShopFilter] = useState<'new' | 'all' | null>(null);

  // Modals & Drawers state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Tracking state passed from checkout or direct
  const [trackingOrderNumber, setTrackingOrderNumber] = useState('');
  const [trackingPhone, setTrackingPhone] = useState('');

  // Navigation handlers
  const handleNavigateHome = () => {
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateShop = (category?: ProductCategory | 'all' | 'new') => {
    if (category === 'new') {
      setShopCategory(null);
      setShopFilter('new');
    } else if (category && category !== 'all') {
      setShopCategory(category);
      setShopFilter(null);
    } else {
      setShopCategory(null);
      setShopFilter(null);
    }
    setCurrentView('shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateTracking = (orderNum?: string, phoneNum?: string) => {
    if (orderNum) setTrackingOrderNumber(orderNum);
    if (phoneNum) setTrackingPhone(phoneNum);
    setCurrentView('tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateAbout = () => {
    if (currentView !== 'home') {
      setCurrentView('home');
      setTimeout(() => {
        const el = document.getElementById('brand-story');
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById('brand-story');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Instant Buy Now: adds to cart & opens checkout immediately
  const handleInstantBuyNow = (product: Product, quantity: number, selectedSize?: string) => {
    addToCart(product, quantity, selectedSize);
    setIsCheckoutOpen(true);
  };

  // Signature hero piece
  const heroProduct = products.find((p) => p.id === 'zn-prod-001') || products[0];

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col font-sans selection:bg-[#D6B16D] selection:text-black">
      
      {/* 1. Sticky Luxury Navigation */}
      <Header
        currentView={currentView}
        onNavigateHome={handleNavigateHome}
        onNavigateShop={handleNavigateShop}
        onNavigateAbout={handleNavigateAbout}
        onNavigateTracking={() => handleNavigateTracking()}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        onOpenWishlist={() => setIsAccountOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* 2. Main View Content */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            <Hero
              onShopCollection={() => handleNavigateShop('all')}
              onExploreMore={() => {
                const el = document.getElementById('brand-story');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              onSelectCategory={handleNavigateShop}
              onQuickViewHeroProduct={() => setSelectedProductForModal(heroProduct)}
            />

            <CategoryShowcase
              onSelectCategory={(cat) => handleNavigateShop(cat)}
            />

            <FeaturedCollection
              onQuickView={(p) => setSelectedProductForModal(p)}
              onNavigateShop={handleNavigateShop}
            />

            <div id="brand-story">
              <BrandStory />
            </div>

            <NewArrivals
              onQuickView={(p) => setSelectedProductForModal(p)}
              onNavigateShop={() => handleNavigateShop('new')}
            />

            <PromotionalBanner
              onNavigateShop={(cat) => handleNavigateShop(cat)}
            />

            <CustomerTestimonials />
          </>
        )}

        {currentView === 'shop' && (
          <ShopPage
            initialCategory={shopCategory}
            initialFilter={shopFilter}
            onQuickView={(p) => setSelectedProductForModal(p)}
          />
        )}

        {currentView === 'tracking' && (
          <OrderTrackingView
            initialOrderNumber={trackingOrderNumber}
            initialPhone={trackingPhone}
            onExploreCollections={() => handleNavigateShop('all')}
          />
        )}
      </main>

      {/* 3. Luxury Footer */}
      <Footer
        onNavigateCategory={handleNavigateShop}
        onNavigateTracking={() => handleNavigateTracking()}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* 4. Modals, Drawers & Portals */}
      <CartDrawer
        onProceedToCheckout={() => setIsCheckoutOpen(true)}
        onExploreProducts={() => handleNavigateShop('all')}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onViewOrderTracking={(orderNum, phone) => {
          setIsCheckoutOpen(false);
          handleNavigateTracking(orderNum, phone);
        }}
      />

      <ProductDetailModal
        product={selectedProductForModal}
        onClose={() => setSelectedProductForModal(null)}
        onInstantBuyNow={handleInstantBuyNow}
        onSelectRelatedProduct={(rel) => setSelectedProductForModal(rel)}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(p) => setSelectedProductForModal(p)}
        onSelectCategory={(cat) => handleNavigateShop(cat as ProductCategory)}
      />

      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        onTrackOrder={(orderNum, phone) => {
          setIsAccountOpen(false);
          handleNavigateTracking(orderNum, phone);
        }}
        onQuickViewProduct={(p) => setSelectedProductForModal(p)}
      />

      <AdminDashboard
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
      />

      <ConciergeButton />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <ProductProvider>
          <MainApp />
        </ProductProvider>
      </CartProvider>
    </AuthProvider>
  );
}
